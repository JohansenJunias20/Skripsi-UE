// Fill out your copyright notice in the Description page of Project Settings.
#include "Interactibles/VRInteractibleFunctionLibrary.h"
//#include "Engine/Engine.h"

//General Log
DEFINE_LOG_CATEGORY(VRInteractibleFunctionLibraryLog);